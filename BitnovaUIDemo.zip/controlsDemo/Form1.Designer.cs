﻿namespace controlsDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bitnovaBarChart1 = new Bitnova.UI.BitnovaBarChart();
            this.bitnovaModernTable2 = new Bitnova.UI.Controls.BitnovaModernTable();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bitnovaButton5 = new Bitnova.UI.WinForms.Controls.BitnovaButton();
            this.bitnovaButton4 = new Bitnova.UI.WinForms.Controls.BitnovaButton();
            this.bitnovaButton3 = new Bitnova.UI.WinForms.Controls.BitnovaButton();
            this.bitnovaButton2 = new Bitnova.UI.WinForms.Controls.BitnovaButton();
            this.bitnovaButton1 = new Bitnova.UI.WinForms.Controls.BitnovaButton();
            this.bitnovaGradientButton1 = new Bitnova.UI.WinForms.Controls.BitnovaGradientButton();
            this.bitnovaPictureBox1 = new Bitnova.UI.Controls.BitnovaPictureBox();
            this.bitnovaTabs1 = new Bitnova.UI.BitnovaTabs();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.bitnovaShadowPanel2 = new Bitnova.UI.BitnovaShadowPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.bitnovaTables1 = new Bitnova.UI.BitnovaTables();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bitnovaRadialGauge1 = new Bitnova.UI.BitnovaRadialGauge();
            this.bitnovaDates1 = new Bitnova.UI.Controls.BitnovaDates();
            this.bitnovaPanel1 = new Bitnova.UI.BitnovaPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bitnovaLabel1 = new Bitnova.UI.BitnovaLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bitnovaTextbox1 = new Bitnova.UI.BitnovaTextbox();
            this.bitnovaIconButton1 = new Bitnova.UI.BitnovaIconButton();
            this.bitnovaPictureBox2 = new Bitnova.UI.Controls.BitnovaPictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.bitnovaModernTable2)).BeginInit();
            this.panel1.SuspendLayout();
            this.bitnovaTabs1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.bitnovaShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bitnovaTables1)).BeginInit();
            this.bitnovaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bitnovaBarChart1
            // 
            this.bitnovaBarChart1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaBarChart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaBarChart1.ChartBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaBarChart1.DataSource = null;
            this.bitnovaBarChart1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bitnovaBarChart1.ForeColor = System.Drawing.Color.White;
            this.bitnovaBarChart1.GridLineCount = 5;
            this.bitnovaBarChart1.LabelMember = null;
            this.bitnovaBarChart1.Location = new System.Drawing.Point(185, 235);
            this.bitnovaBarChart1.Name = "bitnovaBarChart1";
            this.bitnovaBarChart1.Padding = new System.Windows.Forms.Padding(60, 20, 20, 60);
            this.bitnovaBarChart1.RealTime = false;
            this.bitnovaBarChart1.RefreshInterval = 2000;
            this.bitnovaBarChart1.SeriesMember = null;
            this.bitnovaBarChart1.ShowLegend = true;
            this.bitnovaBarChart1.Size = new System.Drawing.Size(891, 254);
            this.bitnovaBarChart1.TabIndex = 0;
            this.bitnovaBarChart1.Text = "bitnovaBarChart1";
            this.bitnovaBarChart1.ValueMember = null;
            this.bitnovaBarChart1.YAxisLabel = "Values";
            // 
            // bitnovaModernTable2
            // 
            this.bitnovaModernTable2.AllowUserToAddRows = false;
            this.bitnovaModernTable2.AllowUserToResizeColumns = false;
            this.bitnovaModernTable2.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(35)))));
            this.bitnovaModernTable2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.bitnovaModernTable2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaModernTable2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bitnovaModernTable2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bitnovaModernTable2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.bitnovaModernTable2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bitnovaModernTable2.CustomThemeColors = null;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(55)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bitnovaModernTable2.DefaultCellStyle = dataGridViewCellStyle9;
            this.bitnovaModernTable2.EnableHeadersVisualStyles = false;
            this.bitnovaModernTable2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.bitnovaModernTable2.Location = new System.Drawing.Point(185, 506);
            this.bitnovaModernTable2.Name = "bitnovaModernTable2";
            this.bitnovaModernTable2.ProgressGradientEnabled = true;
            this.bitnovaModernTable2.RowHeadersVisible = false;
            this.bitnovaModernTable2.RowTemplate.Height = 54;
            this.bitnovaModernTable2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bitnovaModernTable2.Size = new System.Drawing.Size(891, 317);
            this.bitnovaModernTable2.TabIndex = 2;
            this.bitnovaModernTable2.Theme = Bitnova.UI.Controls.BitnovaTheme.Dark;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.bitnovaButton5);
            this.panel1.Controls.Add(this.bitnovaButton4);
            this.panel1.Controls.Add(this.bitnovaButton3);
            this.panel1.Controls.Add(this.bitnovaButton2);
            this.panel1.Controls.Add(this.bitnovaButton1);
            this.panel1.Controls.Add(this.bitnovaGradientButton1);
            this.panel1.Controls.Add(this.bitnovaPictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(163, 841);
            this.panel1.TabIndex = 3;
            // 
            // bitnovaButton5
            // 
            this.bitnovaButton5.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaButton5.BackgroundColor = System.Drawing.Color.Transparent;
            this.bitnovaButton5.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bitnovaButton5.BorderRadius = 0;
            this.bitnovaButton5.BorderSize = 0;
            this.bitnovaButton5.FlatAppearance.BorderSize = 0;
            this.bitnovaButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bitnovaButton5.ForeColor = System.Drawing.Color.White;
            this.bitnovaButton5.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaButton5.Image")));
            this.bitnovaButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaButton5.Location = new System.Drawing.Point(9, 302);
            this.bitnovaButton5.Name = "bitnovaButton5";
            this.bitnovaButton5.Size = new System.Drawing.Size(150, 40);
            this.bitnovaButton5.TabIndex = 7;
            this.bitnovaButton5.Text = "Settings";
            this.bitnovaButton5.TextColor = System.Drawing.Color.White;
            this.bitnovaButton5.UseVisualStyleBackColor = false;
            // 
            // bitnovaButton4
            // 
            this.bitnovaButton4.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaButton4.BackgroundColor = System.Drawing.Color.Transparent;
            this.bitnovaButton4.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bitnovaButton4.BorderRadius = 0;
            this.bitnovaButton4.BorderSize = 0;
            this.bitnovaButton4.FlatAppearance.BorderSize = 0;
            this.bitnovaButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bitnovaButton4.ForeColor = System.Drawing.Color.White;
            this.bitnovaButton4.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaButton4.Image")));
            this.bitnovaButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaButton4.Location = new System.Drawing.Point(9, 256);
            this.bitnovaButton4.Name = "bitnovaButton4";
            this.bitnovaButton4.Size = new System.Drawing.Size(150, 40);
            this.bitnovaButton4.TabIndex = 6;
            this.bitnovaButton4.Text = "Reports";
            this.bitnovaButton4.TextColor = System.Drawing.Color.White;
            this.bitnovaButton4.UseVisualStyleBackColor = false;
            // 
            // bitnovaButton3
            // 
            this.bitnovaButton3.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaButton3.BackgroundColor = System.Drawing.Color.Transparent;
            this.bitnovaButton3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bitnovaButton3.BorderRadius = 0;
            this.bitnovaButton3.BorderSize = 0;
            this.bitnovaButton3.FlatAppearance.BorderSize = 0;
            this.bitnovaButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bitnovaButton3.ForeColor = System.Drawing.Color.White;
            this.bitnovaButton3.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaButton3.Image")));
            this.bitnovaButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaButton3.Location = new System.Drawing.Point(9, 210);
            this.bitnovaButton3.Name = "bitnovaButton3";
            this.bitnovaButton3.Size = new System.Drawing.Size(150, 40);
            this.bitnovaButton3.TabIndex = 5;
            this.bitnovaButton3.Text = "Tickets";
            this.bitnovaButton3.TextColor = System.Drawing.Color.White;
            this.bitnovaButton3.UseVisualStyleBackColor = false;
            // 
            // bitnovaButton2
            // 
            this.bitnovaButton2.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaButton2.BackgroundColor = System.Drawing.Color.Transparent;
            this.bitnovaButton2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bitnovaButton2.BorderRadius = 0;
            this.bitnovaButton2.BorderSize = 0;
            this.bitnovaButton2.FlatAppearance.BorderSize = 0;
            this.bitnovaButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bitnovaButton2.ForeColor = System.Drawing.Color.White;
            this.bitnovaButton2.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaButton2.Image")));
            this.bitnovaButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaButton2.Location = new System.Drawing.Point(9, 164);
            this.bitnovaButton2.Name = "bitnovaButton2";
            this.bitnovaButton2.Size = new System.Drawing.Size(150, 40);
            this.bitnovaButton2.TabIndex = 4;
            this.bitnovaButton2.Text = "    Customers";
            this.bitnovaButton2.TextColor = System.Drawing.Color.White;
            this.bitnovaButton2.UseVisualStyleBackColor = false;
            // 
            // bitnovaButton1
            // 
            this.bitnovaButton1.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaButton1.BackgroundColor = System.Drawing.Color.Transparent;
            this.bitnovaButton1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bitnovaButton1.BorderRadius = 0;
            this.bitnovaButton1.BorderSize = 0;
            this.bitnovaButton1.FlatAppearance.BorderSize = 0;
            this.bitnovaButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bitnovaButton1.ForeColor = System.Drawing.Color.White;
            this.bitnovaButton1.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaButton1.Image")));
            this.bitnovaButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaButton1.Location = new System.Drawing.Point(9, 118);
            this.bitnovaButton1.Name = "bitnovaButton1";
            this.bitnovaButton1.Size = new System.Drawing.Size(150, 40);
            this.bitnovaButton1.TabIndex = 3;
            this.bitnovaButton1.Text = "     Dashboard";
            this.bitnovaButton1.TextColor = System.Drawing.Color.White;
            this.bitnovaButton1.UseVisualStyleBackColor = false;
            // 
            // bitnovaGradientButton1
            // 
            this.bitnovaGradientButton1.BackColor = System.Drawing.Color.Teal;
            this.bitnovaGradientButton1.BackgroundColor = System.Drawing.Color.Teal;
            this.bitnovaGradientButton1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bitnovaGradientButton1.BorderRadius = 15;
            this.bitnovaGradientButton1.BorderSize = 0;
            this.bitnovaGradientButton1.EnableGradient = true;
            this.bitnovaGradientButton1.FlatAppearance.BorderSize = 0;
            this.bitnovaGradientButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bitnovaGradientButton1.ForeColor = System.Drawing.Color.White;
            this.bitnovaGradientButton1.GradientAngle = 90F;
            this.bitnovaGradientButton1.GradientColor1 = System.Drawing.Color.Teal;
            this.bitnovaGradientButton1.GradientColor2 = System.Drawing.Color.DodgerBlue;
            this.bitnovaGradientButton1.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaGradientButton1.Image")));
            this.bitnovaGradientButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaGradientButton1.Location = new System.Drawing.Point(12, 783);
            this.bitnovaGradientButton1.Name = "bitnovaGradientButton1";
            this.bitnovaGradientButton1.Size = new System.Drawing.Size(147, 40);
            this.bitnovaGradientButton1.TabIndex = 3;
            this.bitnovaGradientButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bitnovaGradientButton1.TextColor = System.Drawing.Color.White;
            this.bitnovaGradientButton1.UseVisualStyleBackColor = false;
            // 
            // bitnovaPictureBox1
            // 
            this.bitnovaPictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaPictureBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaPictureBox1.BorderRadius = 50;
            this.bitnovaPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaPictureBox1.Image")));
            this.bitnovaPictureBox1.Location = new System.Drawing.Point(31, 12);
            this.bitnovaPictureBox1.Name = "bitnovaPictureBox1";
            this.bitnovaPictureBox1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bitnovaPictureBox1.Size = new System.Drawing.Size(100, 100);
            this.bitnovaPictureBox1.TabIndex = 0;
            this.bitnovaPictureBox1.Text = "bitnovaPictureBox1";
            this.bitnovaPictureBox1.UseDropShadow = false;
            // 
            // bitnovaTabs1
            // 
            this.bitnovaTabs1.ActiveTabColor = System.Drawing.Color.CadetBlue;
            this.bitnovaTabs1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaTabs1.Controls.Add(this.tabPage1);
            this.bitnovaTabs1.Controls.Add(this.tabPage2);
            this.bitnovaTabs1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.bitnovaTabs1.InactiveTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bitnovaTabs1.ItemSize = new System.Drawing.Size(120, 40);
            this.bitnovaTabs1.Location = new System.Drawing.Point(1083, 63);
            this.bitnovaTabs1.Name = "bitnovaTabs1";
            this.bitnovaTabs1.SelectedIndex = 0;
            this.bitnovaTabs1.Size = new System.Drawing.Size(304, 153);
            this.bitnovaTabs1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.bitnovaTabs1.TabCornerRadius = 1;
            this.bitnovaTabs1.TabIndex = 5;
            this.bitnovaTabs1.TabTextColor = System.Drawing.Color.White;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(296, 105);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Open Tickets";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(103, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "12 tickets.";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 44);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(296, 105);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Resolved Tickets";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(108, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "2 tickets.";
            // 
            // bitnovaShadowPanel2
            // 
            this.bitnovaShadowPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaShadowPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaShadowPanel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaShadowPanel2.BorderThickness = 1;
            this.bitnovaShadowPanel2.Controls.Add(this.label5);
            this.bitnovaShadowPanel2.Controls.Add(this.bitnovaTables1);
            this.bitnovaShadowPanel2.Controls.Add(this.bitnovaRadialGauge1);
            this.bitnovaShadowPanel2.CornerRadius = 10;
            this.bitnovaShadowPanel2.Location = new System.Drawing.Point(1087, 235);
            this.bitnovaShadowPanel2.Name = "bitnovaShadowPanel2";
            this.bitnovaShadowPanel2.PanelBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaShadowPanel2.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bitnovaShadowPanel2.ShadowDepth = 5;
            this.bitnovaShadowPanel2.Size = new System.Drawing.Size(300, 232);
            this.bitnovaShadowPanel2.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(57, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(179, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Tickets with High Priority";
            // 
            // bitnovaTables1
            // 
            this.bitnovaTables1.AllowUserToAddRows = false;
            this.bitnovaTables1.AllowUserToDeleteRows = false;
            this.bitnovaTables1.AllowUserToResizeColumns = false;
            this.bitnovaTables1.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.bitnovaTables1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.bitnovaTables1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bitnovaTables1.BackgroundColor = System.Drawing.Color.White;
            this.bitnovaTables1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bitnovaTables1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.bitnovaTables1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bitnovaTables1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.bitnovaTables1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bitnovaTables1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(215)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bitnovaTables1.DefaultCellStyle = dataGridViewCellStyle12;
            this.bitnovaTables1.EnableHeadersVisualStyles = false;
            this.bitnovaTables1.GridColor = System.Drawing.Color.LightGray;
            this.bitnovaTables1.Location = new System.Drawing.Point(19, -117);
            this.bitnovaTables1.MultiSelect = false;
            this.bitnovaTables1.Name = "bitnovaTables1";
            this.bitnovaTables1.ReadOnly = true;
            this.bitnovaTables1.RowHeadersVisible = false;
            this.bitnovaTables1.RowTemplate.Height = 32;
            this.bitnovaTables1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bitnovaTables1.Size = new System.Drawing.Size(240, 86);
            this.bitnovaTables1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "#TKT ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Issue";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Status";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // bitnovaRadialGauge1
            // 
            this.bitnovaRadialGauge1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaRadialGauge1.EdgeRadius = 20;
            this.bitnovaRadialGauge1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bitnovaRadialGauge1.GaugePadding = 30;
            this.bitnovaRadialGauge1.Location = new System.Drawing.Point(47, 44);
            this.bitnovaRadialGauge1.MaxValue = 100;
            this.bitnovaRadialGauge1.Name = "bitnovaRadialGauge1";
            this.bitnovaRadialGauge1.Size = new System.Drawing.Size(189, 185);
            this.bitnovaRadialGauge1.TabIndex = 0;
            this.bitnovaRadialGauge1.Text = "bitnovaRadialGauge1";
            this.bitnovaRadialGauge1.Value = 70;
            // 
            // bitnovaDates1
            // 
            this.bitnovaDates1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaDates1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaDates1.BorderColor = System.Drawing.Color.Gray;
            this.bitnovaDates1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bitnovaDates1.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.bitnovaDates1.HighlightColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.bitnovaDates1.Location = new System.Drawing.Point(1087, 473);
            this.bitnovaDates1.Name = "bitnovaDates1";
            this.bitnovaDates1.SelectedDate = new System.DateTime(2025, 10, 6, 19, 11, 0, 0);
            this.bitnovaDates1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bitnovaDates1.Size = new System.Drawing.Size(300, 350);
            this.bitnovaDates1.TabIndex = 7;
            this.bitnovaDates1.Text = "bitnovaDates1";
            this.bitnovaDates1.Theme = Bitnova.UI.Controls.DatePickerTheme.Calendar;
            this.bitnovaDates1.UseAnimation = false;
            this.bitnovaDates1.UseDropShadow = false;
            // 
            // bitnovaPanel1
            // 
            this.bitnovaPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaPanel1.BorderColor = System.Drawing.Color.Gray;
            this.bitnovaPanel1.BorderRadius = 5;
            this.bitnovaPanel1.BorderThickness = 1;
            this.bitnovaPanel1.Controls.Add(this.label2);
            this.bitnovaPanel1.Controls.Add(this.label1);
            this.bitnovaPanel1.Controls.Add(this.bitnovaLabel1);
            this.bitnovaPanel1.Controls.Add(this.pictureBox1);
            this.bitnovaPanel1.DropShadowEnabled = true;
            this.bitnovaPanel1.GradientEnabled = true;
            this.bitnovaPanel1.GradientEndColor = System.Drawing.Color.MediumTurquoise;
            this.bitnovaPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.bitnovaPanel1.GradientStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bitnovaPanel1.Location = new System.Drawing.Point(185, 63);
            this.bitnovaPanel1.Name = "bitnovaPanel1";
            this.bitnovaPanel1.ShadowBlur = 5;
            this.bitnovaPanel1.ShadowColor = System.Drawing.Color.Black;
            this.bitnovaPanel1.ShadowOffsetX = 2;
            this.bitnovaPanel1.ShadowOffsetY = 2;
            this.bitnovaPanel1.ShowBorders = false;
            this.bitnovaPanel1.Size = new System.Drawing.Size(891, 149);
            this.bitnovaPanel1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label2.Location = new System.Drawing.Point(161, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "View Tickets";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(125, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "You have 12 new tickets.";
            // 
            // bitnovaLabel1
            // 
            this.bitnovaLabel1.AutoEllipsis = false;
            this.bitnovaLabel1.AutoSizeToFit = false;
            this.bitnovaLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bitnovaLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bitnovaLabel1.ForeColor = System.Drawing.Color.White;
            this.bitnovaLabel1.GlowColor = System.Drawing.Color.White;
            this.bitnovaLabel1.GlowStrength = 5;
            this.bitnovaLabel1.GradientColor1 = System.Drawing.Color.DeepSkyBlue;
            this.bitnovaLabel1.GradientColor2 = System.Drawing.Color.MediumVioletRed;
            this.bitnovaLabel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.bitnovaLabel1.Location = new System.Drawing.Point(99, 26);
            this.bitnovaLabel1.Name = "bitnovaLabel1";
            this.bitnovaLabel1.ShadowColor = System.Drawing.Color.Gray;
            this.bitnovaLabel1.ShadowDepth = 2;
            this.bitnovaLabel1.Size = new System.Drawing.Size(245, 23);
            this.bitnovaLabel1.TabIndex = 1;
            this.bitnovaLabel1.Text = "Welcome back, Pete!";
            this.bitnovaLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bitnovaLabel1.UseGlow = false;
            this.bitnovaLabel1.UseGradient = false;
            this.bitnovaLabel1.UseShadow = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(631, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(257, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // bitnovaTextbox1
            // 
            this.bitnovaTextbox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.bitnovaTextbox1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.bitnovaTextbox1.BorderColor = System.Drawing.Color.White;
            this.bitnovaTextbox1.BorderSize = 2;
            this.bitnovaTextbox1.BottomLeftRadius = 8;
            this.bitnovaTextbox1.BottomRightRadius = 8;
            this.bitnovaTextbox1.FocusedBorderColor = System.Drawing.Color.DodgerBlue;
            this.bitnovaTextbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bitnovaTextbox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bitnovaTextbox1.GradientBorderColor = System.Drawing.Color.LightBlue;
            this.bitnovaTextbox1.Icon = ((System.Drawing.Image)(resources.GetObject("bitnovaTextbox1.Icon")));
            this.bitnovaTextbox1.IsPasswordChar = false;
            this.bitnovaTextbox1.Location = new System.Drawing.Point(185, 12);
            this.bitnovaTextbox1.Multiline = false;
            this.bitnovaTextbox1.Name = "bitnovaTextbox1";
            this.bitnovaTextbox1.PlaceholderColor = System.Drawing.Color.Gray;
            this.bitnovaTextbox1.PlaceholderText = "Enter text...";
            this.bitnovaTextbox1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bitnovaTextbox1.ShadowOffset = 3;
            this.bitnovaTextbox1.ShowClearButton = true;
            this.bitnovaTextbox1.Size = new System.Drawing.Size(344, 40);
            this.bitnovaTextbox1.TabIndex = 9;
            this.bitnovaTextbox1.TextColor = System.Drawing.Color.White;
            this.bitnovaTextbox1.TopLeftRadius = 8;
            this.bitnovaTextbox1.TopRightRadius = 8;
            this.bitnovaTextbox1.UseGradientBorder = false;
            this.bitnovaTextbox1.UsePlaceholderFade = true;
            this.bitnovaTextbox1.UseShadow = true;
            // 
            // bitnovaIconButton1
            // 
            this.bitnovaIconButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaIconButton1.BorderRadius = 12;
            this.bitnovaIconButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bitnovaIconButton1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.bitnovaIconButton1.Icon = ((System.Drawing.Image)(resources.GetObject("bitnovaIconButton1.Icon")));
            this.bitnovaIconButton1.IdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.bitnovaIconButton1.Location = new System.Drawing.Point(1287, 12);
            this.bitnovaIconButton1.Name = "bitnovaIconButton1";
            this.bitnovaIconButton1.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(90)))), ((int)(((byte)(134)))));
            this.bitnovaIconButton1.Size = new System.Drawing.Size(31, 30);
            this.bitnovaIconButton1.TabIndex = 10;
            // 
            // bitnovaPictureBox2
            // 
            this.bitnovaPictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bitnovaPictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaPictureBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(25)))));
            this.bitnovaPictureBox2.BorderRadius = 50;
            this.bitnovaPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("bitnovaPictureBox2.Image")));
            this.bitnovaPictureBox2.Location = new System.Drawing.Point(1327, 0);
            this.bitnovaPictureBox2.Name = "bitnovaPictureBox2";
            this.bitnovaPictureBox2.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bitnovaPictureBox2.Size = new System.Drawing.Size(60, 52);
            this.bitnovaPictureBox2.TabIndex = 11;
            this.bitnovaPictureBox2.Text = "bitnovaPictureBox2";
            this.bitnovaPictureBox2.UseDropShadow = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(18)))));
            this.ClientSize = new System.Drawing.Size(1411, 841);
            this.Controls.Add(this.bitnovaPictureBox2);
            this.Controls.Add(this.bitnovaIconButton1);
            this.Controls.Add(this.bitnovaTextbox1);
            this.Controls.Add(this.bitnovaPanel1);
            this.Controls.Add(this.bitnovaDates1);
            this.Controls.Add(this.bitnovaShadowPanel2);
            this.Controls.Add(this.bitnovaTabs1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bitnovaModernTable2);
            this.Controls.Add(this.bitnovaBarChart1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Careflow Helpdesk Sytem";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bitnovaModernTable2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.bitnovaTabs1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.bitnovaShadowPanel2.ResumeLayout(false);
            this.bitnovaShadowPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bitnovaTables1)).EndInit();
            this.bitnovaPanel1.ResumeLayout(false);
            this.bitnovaPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bitnova.UI.BitnovaBarChart bitnovaBarChart1;
        private Bitnova.UI.Controls.BitnovaModernTable bitnovaModernTable2;
        private System.Windows.Forms.Panel panel1;
        private Bitnova.UI.Controls.BitnovaPictureBox bitnovaPictureBox1;
        private Bitnova.UI.BitnovaTabs bitnovaTabs1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private Bitnova.UI.BitnovaShadowPanel bitnovaShadowPanel2;
        private Bitnova.UI.BitnovaRadialGauge bitnovaRadialGauge1;
        private Bitnova.UI.Controls.BitnovaDates bitnovaDates1;
        private Bitnova.UI.BitnovaPanel bitnovaPanel1;
        private Bitnova.UI.BitnovaLabel bitnovaLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bitnova.UI.WinForms.Controls.BitnovaGradientButton bitnovaGradientButton1;
        private System.Windows.Forms.Label label1;
        private Bitnova.UI.WinForms.Controls.BitnovaButton bitnovaButton1;
        private System.Windows.Forms.Label label2;
        private Bitnova.UI.WinForms.Controls.BitnovaButton bitnovaButton5;
        private Bitnova.UI.WinForms.Controls.BitnovaButton bitnovaButton4;
        private Bitnova.UI.WinForms.Controls.BitnovaButton bitnovaButton3;
        private Bitnova.UI.WinForms.Controls.BitnovaButton bitnovaButton2;
        private Bitnova.UI.BitnovaTables bitnovaTables1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Bitnova.UI.BitnovaTextbox bitnovaTextbox1;
        private Bitnova.UI.BitnovaIconButton bitnovaIconButton1;
        private Bitnova.UI.Controls.BitnovaPictureBox bitnovaPictureBox2;
        private System.Windows.Forms.Label label5;
    }
}

