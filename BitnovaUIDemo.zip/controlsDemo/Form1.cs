﻿using Bitnova.UI.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace controlsDemo
{
    public partial class Form1 : Form
    {
        private Bitnova.UI.BitnovaBarChart chart;
        public Form1()
        {
            InitializeComponent();
            ConfigureTable(bitnovaModernTable2);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadDemoData();
            var salesData = new List<SalesData>
        {
            new SalesData { Month = "Jan", Sales = 4200, Region = "East" },
            new SalesData { Month = "Feb", Sales = 3800, Region = "East" },
            new SalesData { Month = "Mar", Sales = 6100, Region = "East" },
            new SalesData { Month = "Apr", Sales = 5400, Region = "East" },
            new SalesData { Month = "May", Sales = 7200, Region = "East" },

            new SalesData { Month = "Jan", Sales = 4000, Region = "West" },
            new SalesData { Month = "Feb", Sales = 3700, Region = "West" },
            new SalesData { Month = "Mar", Sales = 6400, Region = "West" },
            new SalesData { Month = "Apr", Sales = 5000, Region = "West" },
            new SalesData { Month = "May", Sales = 7000, Region = "West" },
        };

            // --- Bind chart ---
            bitnovaBarChart1.DataSource = salesData;
            bitnovaBarChart1.LabelMember = "Month";     // X-axis labels
            bitnovaBarChart1.ValueMember = "Sales";     // Bar height
            bitnovaBarChart1.SeriesMember = "Region";   // Optional grouping
            bitnovaBarChart1.YAxisLabel = "Sales (USD)";

            bitnovaBarChart1.RefreshInterval = 3000;    // Optional
            bitnovaBarChart1.RealTime = false;
        }
        public class SalesData
        {
            public string Month { get; set; }
            public double Sales { get; set; }
            public string Region { get; set; } // optional (for multi-series demo)
        }
        private void ConfigureTable(BitnovaModernTable table)
        {
            //table.Dock = DockStyle.Fill;
            //table.Theme = TableTheme.Dark; // can also be Light or Custom

            // Setup columns if not auto-created
            table.Columns.Clear();
            table.Columns.Add(new IconCircleColumn());
            table.Columns.Add(new AvatarColumn());

            table.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Name",
                Width = 220
            });

            table.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Email",
                Width = 320
            });

            table.Columns.Add(new BadgeColumn() { HeaderText = "Status" });
            table.Columns.Add(new GradientProgressColumn() { HeaderText = "Progress" });
        }

        private void LoadDemoData()
        {
            var table = bitnovaModernTable2;
            table.Rows.Clear();

            for (int i = 0; i < 9; i++)
            {
                int idx = table.Rows.Add();

                table.Rows[idx].Cells[0].Value = ""; // Icon column placeholder
                table.Rows[idx].Cells[1].Value = "John Doe " + i; // Avatar column
                table.Rows[idx].Cells[2].Value = "John Doe " + i; // Name
                table.Rows[idx].Cells[3].Value = "johndoe@gmail.com"; // Email
                table.Rows[idx].Cells[4].Value = (i % 2 == 0) ? "Active" : "Pending"; // Status
                table.Rows[idx].Cells[5].Value = (20 + i * 8).ToString(); // Progress %

                // Subtle alternating background
                if (i % 2 == 0)
                    table.Rows[idx].DefaultCellStyle.BackColor = Color.FromArgb(21, 19, 30);
            }

            // --- Footer Panel (attached to table container) ---
            var footer = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = Color.FromArgb(12, 10, 18)
            };

            // Left info label
            var labelInfo = new Label
            {
                AutoSize = true,
                Text = "9 • 100",
                ForeColor = Color.FromArgb(150, 150, 160),
                Location = new Point(12, 16)
            };
            footer.Controls.Add(labelInfo);

            // Next page button (right aligned)
            var nextButton = new Button
            {
                Text = ">",
                Width = 44,
                Height = 36,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(244, 114, 182),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            nextButton.FlatAppearance.BorderSize = 0;

            // Position button near right edge of footer
            footer.Resize += (s, e) =>
            {
                nextButton.Left = footer.Width - nextButton.Width - 20;
                nextButton.Top = (footer.Height - nextButton.Height) / 2;
            };

            footer.Controls.Add(nextButton);

            // --- Wrap table and footer in container panel ---
            var container = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = this.BackColor
            };

            // Add table (already configured)
         table = bitnovaModernTable2;
           // table.Dock = DockStyle.Fill;
            container.Controls.Add(table);

            // Add footer to container
           // container.Controls.Add(footer);

            // Add container to form
            this.Controls.Add(container);

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
    }
}
